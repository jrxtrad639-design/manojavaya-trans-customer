# Deployment — Manojavaya Trans Customer v1.1.4

1. Upload the **contents** of this folder to a static HTTPS host (Cloudflare Pages is recommended, GitHub Pages also works).
2. Keep `index.html`, `manifest.webmanifest`, `sw.js`, and `assets/` at the same root level.
3. Do not rename the asset files.
4. The page must be served over HTTPS for the PWA/service worker to work (localhost is also allowed for development).
5. After deployment, open the customer URL on Android Chrome/Safari and use the browser's **Add to Home screen** option. The Manojavaya Trans logo is declared as the PWA icon.
6. Test a real booking. It should create a `request_id` through the production Cloudflare API. The Driver app must then show it under Pending/New Customer Booking.

## Production API used by this build
Base: `https://manojavaya-trans-api.manojavaya-trans.workers.dev`
POST: `/api/booking-requests`

## Compatibility target
Designed to work with the uploaded `Manojavaya_Trans_Driver_V1.1.4_FINAL_PRODUCTION_2_VERIFIED.zip`, which uses the same API base and booking-request flow.

## Smoke test
- Customer submits booking.
- Customer receives Booking ID.
- Driver opens/reloads Incoming Customer Booking.
- Driver sees the new request as PENDING.
- Driver accepts/rejects it.
- On accept, Driver continues its existing order/WhatsApp flow.

If the Customer succeeds but Driver does not see the request, the problem is in the Cloudflare Worker/API routing, authentication/driver assignment, or production deployment—not in the Customer ZIP.
